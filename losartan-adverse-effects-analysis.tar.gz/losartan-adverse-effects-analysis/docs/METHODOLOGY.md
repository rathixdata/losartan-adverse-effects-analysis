# Methodology Documentation

## Losartan 50mg Adverse Effects Analysis - Detailed Methodology

---

## Table of Contents

1. [Data Collection](#data-collection)
2. [Data Preprocessing](#data-preprocessing)
3. [Feature Engineering](#feature-engineering)
4. [Machine Learning Models](#machine-learning-models)
5. [Propensity Scoring](#propensity-scoring)
6. [Statistical Analysis](#statistical-analysis)
7. [Evaluation Metrics](#evaluation-metrics)

---

## Data Collection

### Data Sources

The analysis utilizes adverse event reports from multiple pharmacovigilance databases:

1. **FDA FAERS** (Food and Drug Administration Adverse Event Reporting System)
   - Primary data source
   - Accessed via openFDA API
   - URL: https://api.fda.gov/drug/event.json

2. **EU EudraVigilance**
   - European Medicines Agency database
   - URL: https://www.adrreports.eu

3. **WHO VigiAccess**
   - World Health Organization global database
   - URL: https://www.vigiaccess.org

4. **Health Canada Adverse Reaction Database**
   - Canadian pharmacovigilance data

5. **OpenVigil**
   - Open-source pharmacovigilance analytics platform

### API Access

```python
base_url = "https://api.fda.gov/drug/event.json"
params = {
    'search': 'patient.drug.medicinalproduct:"losartan"',
    'limit': 100,
    'skip': 0
}
```

### Data Structure

Each FAERS report contains:
- **Patient demographics**: age, sex, weight
- **Drug information**: medicinal product, dosage, indication
- **Adverse reactions**: MedDRA preferred terms
- **Outcomes**: death, hospitalization, life-threatening, disabling
- **Reporter information**: qualification (physician, pharmacist, etc.)

---

## Data Preprocessing

### Missing Value Handling

```python
# Numerical features: Median imputation
df['age'].fillna(df['age'].median(), inplace=True)
df['weight'].fillna(df['weight'].median(), inplace=True)

# Categorical features: Mode or 'Unknown' category
df['sex'].fillna('Unknown', inplace=True)
df['reporter_qualification'].fillna(0, inplace=True)
```

### Data Quality Checks

1. **Outlier detection**: Age and weight validated against physiological ranges
2. **Duplicate removal**: Based on report ID and timestamp
3. **Consistency checks**: Cross-validation of severity indicators

---

## Feature Engineering

### Derived Features

#### 1. Age Groups
```python
df['age_group'] = pd.cut(df['age'], 
                         bins=[0, 18, 40, 60, 80, 120], 
                         labels=['0-18', '19-40', '41-60', '61-80', '80+'])
```

#### 2. Severity Score
Composite score based on FDA serious outcome criteria:
```python
severity_score = (
    serious_death * 4 +           # Highest weight
    serious_life_threatening * 3 +
    serious_hospitalization * 2 +
    serious_disabling * 1
)
```

#### 3. Binary Target Variable
```python
df['is_serious'] = (df['severity_score'] > 0).astype(int)
```

#### 4. Adverse Event Frequency
```python
ae_freq = df['adverse_event'].value_counts()
df['ae_frequency'] = df['adverse_event'].map(ae_freq)
```

### Categorical Encoding

**Label Encoding** used for:
- Sex: {M: 0, F: 1, Unknown: 2}
- Age groups: {0-18: 0, 19-40: 1, 41-60: 2, 61-80: 3, 80+: 4}

**Rationale**: Ordinal relationship exists for age groups; simple encoding sufficient for sex with limited categories.

---

## Machine Learning Models

### Train-Test Split

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2,      # 80/20 split
    random_state=42,    # Reproducibility
    stratify=y          # Preserve class distribution
)
```

### Feature Scaling

```python
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
```

**Rationale**: Standardization ensures features with larger scales don't dominate gradient-based models.

### Model Configurations

#### 1. Logistic Regression (Baseline)
```python
LogisticRegression(
    max_iter=1000,
    random_state=42,
    class_weight='balanced'  # Handle class imbalance
)
```

#### 2. Random Forest
```python
RandomForestClassifier(
    n_estimators=100,      # Number of trees
    max_depth=10,          # Prevent overfitting
    random_state=42,
    class_weight='balanced'
)
```

**Hyperparameters chosen based on:**
- Computational efficiency
- Cross-validation performance
- Generalization capability

#### 3. Gradient Boosting
```python
GradientBoostingClassifier(
    n_estimators=100,
    max_depth=5,           # Shallower trees than RF
    learning_rate=0.1,     # Conservative learning
    random_state=42
)
```

#### 4. Neural Network
```python
MLPClassifier(
    hidden_layer_sizes=(64, 32),  # Two hidden layers
    max_iter=500,
    random_state=42,
    early_stopping=True            # Prevent overfitting
)
```

**Architecture rationale**: 
- First layer (64): Captures complex patterns
- Second layer (32): Dimensionality reduction
- Early stopping: Monitors validation loss

#### 5. Ensemble (Voting Classifier)
```python
VotingClassifier(
    estimators=[
        ('lr', LogisticRegression(...)),
        ('rf', RandomForestClassifier(...)),
        ('gb', GradientBoostingClassifier(...))
    ],
    voting='soft'  # Probability-based voting
)
```

**Rationale**: Combines strengths of multiple models; soft voting leverages prediction probabilities.

---

## Propensity Scoring

### Mathematical Formulation

For each adverse event type:

```python
propensity_score = severity_rate × log(1 + frequency)
reliability_score = min(1.0, frequency / 100)
```

Where:
- **severity_rate**: Proportion of serious events for this adverse event
- **frequency**: Total number of reports for this adverse event
- **log(1 + frequency)**: Logarithmic transformation to prevent frequency dominance

### Interpretation

| Propensity Score | Risk Level | Clinical Action |
|------------------|------------|-----------------|
| > 1.5 | Very High | Immediate monitoring |
| 1.0 - 1.5 | High | Enhanced surveillance |
| 0.5 - 1.0 | Moderate | Standard monitoring |
| < 0.5 | Low | Routine observation |

### Reliability Scoring

Accounts for statistical confidence based on sample size:
- Scores < 0.3: Limited reliability (< 30 reports)
- Scores 0.3-0.7: Moderate reliability (30-70 reports)
- Scores > 0.7: High reliability (> 70 reports)
- Score = 1.0: Maximum reliability (≥ 100 reports)

---

## Statistical Analysis

### 1. Chi-Square Test (Age Group vs. Severity)

**Null Hypothesis**: Age group and severity are independent

```python
chi2, p_value = stats.chi2_contingency(
    pd.crosstab(df['age_group'], df['is_serious'])
)[:2]
```

**Interpretation**:
- p < 0.05: Reject null hypothesis (significant association)
- p ≥ 0.05: Fail to reject null hypothesis

### 2. Independent T-Test (Age Difference)

**Null Hypothesis**: No difference in mean age between serious and non-serious events

```python
serious_ages = df[df['is_serious']==1]['age']
non_serious_ages = df[df['is_serious']==0]['age']
t_stat, p_value = stats.ttest_ind(
    serious_ages, 
    non_serious_ages, 
    nan_policy='omit'
)
```

### 3. Feature Importance Analysis

**Random Forest Feature Importance**:
```python
importances = rf_model.feature_importances_
```

Measures:
- Gini importance (mean decrease in node impurity)
- Normalized across all features
- Higher values indicate stronger predictive power

---

## Evaluation Metrics

### 1. Accuracy

```
Accuracy = (TP + TN) / (TP + TN + FP + FN)
```

**Interpretation**: Overall correctness of predictions

### 2. F1 Score

```
F1 = 2 × (Precision × Recall) / (Precision + Recall)
```

**Interpretation**: Harmonic mean balancing precision and recall
- Particularly important for imbalanced datasets
- Range: 0 (worst) to 1 (best)

### 3. ROC AUC (Receiver Operating Characteristic - Area Under Curve)

**Interpretation**:
- 0.5: Random classifier
- 0.6-0.7: Fair
- 0.7-0.8: Good
- 0.8-0.9: Excellent
- 0.9-1.0: Outstanding

**Advantages**:
- Threshold-independent
- Robust to class imbalance
- Measures discriminative ability

---

## Cross-Validation Strategy

While the main analysis uses a single 80/20 split, the approach supports k-fold cross-validation:

```python
cv_scores = cross_val_score(
    model, 
    X_train_scaled, 
    y_train, 
    cv=5,                    # 5-fold CV
    scoring='roc_auc'
)
```

---

## Computational Considerations

### Performance Optimization

1. **Batch processing**: Data fetched in 100-report batches
2. **Vectorization**: NumPy operations instead of loops
3. **Caching**: Fitted scalers and encoders saved for reuse

### Reproducibility

- Fixed random seed (42) across all stochastic processes
- Stratified sampling maintains class distribution
- Version-controlled dependencies

---

## Limitations and Assumptions

### Data Assumptions

1. **Independence**: Assumes reports are independent observations
2. **Completeness**: Assumes critical fields are accurately reported
3. **Representativeness**: FAERS may not represent all patient populations

### Model Assumptions

1. **Feature independence**: Some models assume feature independence
2. **Linear separability**: Logistic regression assumes linear decision boundaries
3. **No temporal effects**: Current analysis doesn't account for time trends

### Statistical Assumptions

1. **Normal distribution**: T-test assumes normal distribution of ages
2. **Homogeneity of variance**: Equal variance across groups
3. **Random sampling**: Assumes reports represent random sample

---

## Future Enhancements

1. **Temporal analysis**: Track adverse event trends over time
2. **Drug-drug interactions**: Multi-drug analysis
3. **Comorbidity incorporation**: Patient medical history
4. **External validation**: Test models on independent datasets
5. **Deep learning**: Explore neural architectures (LSTM, Transformers)

---

## References

1. FDA FAERS Database Documentation
2. MedDRA Coding System
3. Scikit-learn Documentation
4. Statistical Methods for Pharmacovigilance
5. OpenVigil Methodology Papers

---

**Last Updated**: December 29, 2025
**Version**: 1.0.0
